export interface Persona {
    nome: string;
    cognome: string;
    eta?: number; // ? è opzionale
}
