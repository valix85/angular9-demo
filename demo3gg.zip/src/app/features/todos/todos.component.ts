import {Component, OnInit} from '@angular/core';
import {Todo} from 'src/app/core/model/todo';
import {TodoService} from 'src/app/core/services/todo.service';

@Component({
  selector: 'nxt-todos',
  templateUrl: './todos.component.html',
  styleUrls: ['./todos.component.css']
})
export class TodosComponent implements OnInit {

  items: Todo[] = [
    /*
    {
      id: 104,
      title: 'Fare la spesa',
      content: 'Latte, uova, pane, ecc...',
      done: false
    },
    {
      id: 105,
      title: 'Lavare la macchina',
      content: 'Prendere tutti gli accessori del caso',
      done: false
    },
    {
      id: 106,
      title: 'Pagare l\'assicurazione',
      content: 'Caricare carta per pagare assicurazione',
      done: false
    }
    */
  ];

  constructor(private todosService: TodoService) {
    todosService.getTodos()
      .subscribe(risp => {
        this.items = risp;
      });
  }

  ngOnInit(): void {
  }

  generaTodo(): void {
    const idx = Math.floor(Math.random() * 100);
    const tmp: Todo = {
      // id: idx,
      id: undefined,
      title: 'titolo tmp' + idx,
      content: 'bla bla bla...',
      done: false
    };
    // console.log(tmp);
    this.aggiungiTodo(tmp);
    // this.items = this.todosService.getTodos();
  }

  cambiaStato(item: Todo): void {
    this.todosService.switchState(item.id)
      .subscribe(dati => {
        // se ok riscarico i dati
        this.todosService.getTodos()
          .subscribe(risp2 => {
            this.items = risp2;
          });
      });
    // this.items = this.todosService.getTodos();
  }

  cancellaTodo(item: Todo): void {
    // console.log('cancello: ', item);
    this.todosService.deleteTodo(item.id)
      .subscribe(dati => {
        // se ok riscarico i dati
        this.todosService.getTodos()
          .subscribe(risp2 => {
            this.items = risp2;
          });
      });
    // this.items = this.todosService.getTodos();
  }

  aggiungiTodo(todo: Todo): void {
    this.todosService.addTodo(todo)
      .subscribe(risp => {
        this.todosService.getTodos()
          .subscribe(risp2 => {
            this.items = risp2;
          });
      });
    // this.items = this.todosService.getTodos();

  }

}
